const fs = require('fs-extra');

async function globalSetup() {
	fs.emptyDirSync('downloads');
}

export default globalSetup;
