import { LocustPage } from '@pages/locust.page';
import { test, Page, expect } from '@playwright/test';
import { getDownloadedFileContent } from '@resources/common';
import { locustMenu } from '@resources/locust-handle/common-locust';

export async function ad2003(page: Page): Promise<void> {
    const locustNavigation = new LocustPage(page);
    let content = '';

    await test.step('Rá kell kattintani a navigációs sáv **Eszközök** menüjében lévő **Locust generátor** gombra.', async () => {
        await locustMenu(locustNavigation);
    });

    await test.step('Rá kell kattintani az **Export** gombra.', async () => {
        content = await getDownloadedFileContent(locustNavigation.exportLocustButton, page);
    });

    await test.step('Ellenőrizni kell, hogy a fájl sikeresen letöltődött és tartalmazza a locust modul szerkezeti felépítését.', async () => {
        await expect(content.includes('general')).toBeTruthy();
        await expect(content.includes('modul')).toBeTruthy();
        await expect(content.includes('auth')).toBeTruthy();
        await expect(content.includes('files')).toBeTruthy();
        await expect(content.includes('dictionaries')).toBeTruthy();
    });


}
