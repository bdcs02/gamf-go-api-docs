import { LocustPage } from '@pages/locust.page';
import { test, Page, expect } from '@playwright/test';
import { selectOption } from '@resources/common';
import { locustMenu } from '@resources/locust-handle/common-locust';

export async function ad2105(page: Page, data: any): Promise<void> {
    const locustPage = new LocustPage(page);

    await test.step('Rá kell kattintani a navigációs sáv **Eszközök** menüjében lévő **Locust generátor** gombra.', async () => {
        await locustMenu(locustPage);
    });

    await test.step('Rá kell kattintani a **Modulok** gombra.', async () => {
        await locustPage.moduleTab.click()
    });

    await test.step('Rá kell kattintani a **TESZTELÉS PARAMÉTEREI** táblázat alapján megadott modulra.', async () => {
        await page.getByText(data.defaultModule, { exact: true }).click()
    });

    await test.step('Ki kell választani a **Végpontot** a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
        await page.getByText('Végpontok kiválasztása').click();
        await selectOption(data.endpointLong, page);
    });

    await test.step('Rá kell kattintani a **Hozzáadás** gombra.', async () => {
        await locustPage.addEndpoint.click()
    });

    await test.step('Ellenőrizni kell, hogy a felvett végpont megjelenik a listában.', async () => {
        await expect(page.getByText(data.endpointShort, { exact: true })).toBeVisible();
    });




}
