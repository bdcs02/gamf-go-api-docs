import { LocustPage } from '@pages/locust.page';
import { test, Page, expect } from '@playwright/test';
import { clickConfirm, locustMenu } from '@resources/locust-handle/common-locust';

export async function ad2111(page: Page, data: any): Promise<void> {
    const locustPage = new LocustPage(page);


    await test.step('Rá kell kattintani a navigációs sáv **Eszközök** menüjében lévő **Locust generátor** gombra.', async () => {
        await locustMenu(locustPage);
    });

    await test.step('Rá kell kattintani az **Authorizáció** gombra.', async () => {
        await locustPage.authTab.click()
    });

    await test.step('Rá kell kattintani a **Törlés** gombra.', async () => {
        await locustPage.delete.click();
    });

    await test.step('Rá kell kattintani az **Igen** gombra.', async () => {
        await clickConfirm(page);
    });

    await test.step('Ellenőrizni kell, hogy az authorizáció törlődött a listából. ', async () => {
        await expect(page.getByText(data.defaultAuth)).toHaveCount(0);
    });


}
