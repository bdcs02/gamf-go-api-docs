import { LocustPage } from '@pages/locust.page';
import { test, Page, expect } from '@playwright/test';
import { selectOption } from '@resources/common';
import { locustMenu } from '@resources/locust-handle/common-locust';

export async function ad2121(page: Page, data: any): Promise<void> {
    const locustPage = new LocustPage(page);

    await test.step('Rá kell kattintani a navigációs sáv **Eszközök** menüjében lévő **Locust generátor** gombra.', async () => {
        await locustMenu(locustPage);
    });

    await test.step('Rá kell kattintani az **Általános** gombra.', async () => {
        await locustPage.generalTab.click()
    });

    await test.step('Ki kell tölteni a **Host** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
        await page.locator('#host').fill(data.host);
    });
    await test.step('Ki kell tölteni a **Felhasználók száma** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
        await page.locator('#userNumber').fill(data.userNumber);
    });
    await test.step('Ki kell tölteni a **Spawn rate** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
        await page.locator('#spawnRate').fill(data.spawnRate);
    });
    await test.step('Ki kell választani a **Log level** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
        await page.locator('#logLevel-input').click();
        await selectOption(data.logLevel, page);
    });
    await test.step('Ki kell tölteni a **Futási idő** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
        await page.locator('#runTime').fill(data.runTime);
    });
    await test.step('Ki kell tölteni a **Seed** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
        await page.locator('#seed').fill(data.seed);
    });

    await test.step('Ki kell tölteni a **Locale** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
        await page.locator('#locale-input').click();
        await selectOption(data.locale, page);
    });

    await test.step('Rá kell kattintatni a **Mentés** gombra. ', async () => {
        await page.locator('#locust-save').click();
    });

    await test.step('Ellenőrizni kell, hogy a mentett adat megjelenik a táblázatban.', async () => {
        await expect(page.locator('#host')).toHaveValue(data.host);
    });





}
