import { LocustPage } from '@pages/locust.page';
import { test, Page, expect } from '@playwright/test';
import { locustMenu } from '@resources/locust-handle/common-locust';

export async function ad2101(page: Page, data: any): Promise<void> {
    const locustPage = new LocustPage(page);

    await test.step('Rá kell kattintani a navigációs sáv **Eszközök** menüjében lévő **Locust generátor** gombra.', async () => {
        await locustMenu(locustPage);
    });

    await test.step('Rá kell kattintani a **Modulok** gombra.', async () => {
        await locustPage.moduleTab.click()
    });

    await test.step('Rá kell kattintani a **Hozzáadás** gombra. ', async () => {
        await locustPage.addModul.click();
    });

    await test.step('Ki kell tölteni a **Név** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján. ', async () => {
        await locustPage.nameInput.fill(data.name);
    });

    await test.step('Rá kell kattintani a **Mentés** gombra.', async () => {
        await locustPage.save.click()
    });

    await test.step('Ellenőrizni kell, hogy a felvett modul megjelenik a listában. ', async () => {
        await expect(page.getByText(data.name)).toBeVisible();
    });




}
