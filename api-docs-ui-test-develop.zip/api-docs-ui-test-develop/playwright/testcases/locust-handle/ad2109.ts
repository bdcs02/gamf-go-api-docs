import { LocustPage } from '@pages/locust.page';
import { test, Page, expect } from '@playwright/test';
import { selectOption } from '@resources/common';
import { locustMenu } from '@resources/locust-handle/common-locust';

export async function ad2109(page: Page, data: any): Promise<void> {
    const locustPage = new LocustPage(page);

    await test.step('Rá kell kattintani a navigációs sáv **Eszközök** menüjében lévő **Locust generátor** gombra.', async () => {
        await locustMenu(locustPage);
    });

    await test.step('Rá kell kattintani az **Authorizáció** gombra.', async () => {
        await locustPage.authTab.click()
    });

    await test.step('Ki kell tölteni a **Név** mezőt  a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
        await page.locator('#name').fill(data.add.name)
    });

    await test.step('Ki kell választani az **Authorizáció** a **TESZTELÉS PARAMÉTEREI** táblázat alapján. ', async () => {
        await locustPage.authTypesDropdown.click();
        await selectOption('OAuth', page);
    });

    await test.step('Rá kell kattintani a **Hozzáadás** gombra.', async () => {
        await locustPage.addOnClass.click()
    });

    await test.step('Ellenőrizni kell, hogy a felvett authorizáció megjelenik a listában. ', async () => {
        await expect(page.getByText(data.add.name)).toBeVisible();
    });




}
