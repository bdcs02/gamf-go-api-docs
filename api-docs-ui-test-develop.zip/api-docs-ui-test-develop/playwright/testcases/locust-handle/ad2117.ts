import { LocustPage } from '@pages/locust.page';
import { test, Page, expect } from '@playwright/test';
import { locustMenu } from '@resources/locust-handle/common-locust';

export async function ad2117(page: Page, data: any): Promise<void> {
    const locustPage = new LocustPage(page);

    await test.step('Rá kell kattintani a navigációs sáv **Eszközök** menüjében lévő **Locust generátor** gombra.', async () => {
        await locustMenu(locustPage);
    });

    await test.step('Rá kell kattintani a **Szótárak** gombra.', async () => {
        await locustPage.dictionaryTab.click()
    });

    await test.step('Ki kell tölteni a **Név** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján. ', async () => {
        await page.locator('#name').fill(data.dictionary);
    });

    await test.step('Rá kell kattintani a **Hozzáadás** gombra. ', async () => {
        await locustPage.addOnClass.click();
    });

    await test.step('Rá kell kattintani a **TESZTELÉS PARAMÉTEREI** táblázat alapján felvett szótárra.', async () => {
        await page.getByText(data.dictionary).click();
    });

    await test.step('Rá kell kattintani az **Új szó** gombra.', async () => {
        await locustPage.addWord.click();
    });

    await test.step('Ki kell tölteni a **Szó** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
        await page.locator('#word').fill(data.word);
    });

    await test.step('Ellenőrizni kell, hogy a felvett szó megjelenik a listában.', async () => {
        await expect(page.locator('#word')).toHaveValue(data.word);
    });


}
