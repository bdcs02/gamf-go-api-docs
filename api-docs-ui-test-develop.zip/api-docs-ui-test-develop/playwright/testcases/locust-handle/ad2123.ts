import { LocustPage } from '@pages/locust.page';
import { test, Page, expect } from '@playwright/test';
import { locustMenu } from '@resources/locust-handle/common-locust';

export async function ad2123(page: Page): Promise<void> {
    const locustPage = new LocustPage(page);

    await test.step('Rá kell kattintani a navigációs sáv **Eszközök** menüjében lévő **Locust generátor** gombra.', async () => {
        await locustMenu(locustPage);
    });

    await test.step('Rá kell kattintani a **Modulok** gombra.', async () => {
        await locustPage.moduleTab.click()
    });

    await test.step('Rá kell kattintani a **Megtekintés** gombra.', async () => {
        await locustPage.viewCode.click()
    });

    await test.step('Ellenőrizni kell, hogy a generált kód megjelenik a felugró ablakban. ', async () => {
        await expect(page.getByText('Generált kód', { exact: true })).toBeVisible();
    });




}
