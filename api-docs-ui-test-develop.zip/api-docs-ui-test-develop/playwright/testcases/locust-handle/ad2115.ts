import { LocustPage } from '@pages/locust.page';
import { test, Page, expect } from '@playwright/test';
import { locustMenu, uploadFile } from '@resources/locust-handle/common-locust';
import path from 'path';

export async function ad2115(page: Page, data: any): Promise<void> {
    const locustPage = new LocustPage(page);

    await test.step('Rá kell kattintani a navigációs sáv **Eszközök** menüjében lévő **Locust generátor** gombra.', async () => {
        await locustMenu(locustPage);
    });

    await test.step('Rá kell kattintani a **Fájlok** gombra.', async () => {
        await locustPage.filesTab.click()
    });

    await test.step('Ki kell tölteni a **Kulcs** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
        await page.getByText('Kulcs').fill(data.key)
    });

    await test.step('Ki kell választani a fájlt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
        await uploadFile(locustPage, page);
    });

    await test.step('Rá kell kattintani a **Törlés** gombra. ', async () => {
        await locustPage.delete.click();
    });

    await test.step('Ellenőrizni kell, hogy a fájl törlődött a listából.', async () => {
        await expect(page.getByLabel(data.key)).toHaveCount(0);
    });


}
