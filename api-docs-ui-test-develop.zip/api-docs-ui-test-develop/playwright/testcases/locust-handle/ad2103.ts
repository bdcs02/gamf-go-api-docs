import { LocustPage } from '@pages/locust.page';
import { test, Page, expect } from '@playwright/test';
import { locustMenu } from '@resources/locust-handle/common-locust';

export async function ad2103(page: Page, data: any): Promise<void> {
    const locustPage = new LocustPage(page);

    await test.step('Rá kell kattintani a navigációs sáv **Eszközök** menüjében lévő **Locust generátor** gombra.', async () => {
        await locustMenu(locustPage);
    });

    await test.step('Rá kell kattintani a **Modulok** gombra.', async () => {
        await locustPage.moduleTab.click()
    });

    await test.step('Rá kell kattintani a **Törlés** gombra.', async () => {
        await locustPage.delete.click()
    });

    await test.step('Rá kell kattintani az **Igen** gombra.', async () => {
        await locustPage.dialogConfirm.click();
    });

    await test.step('Ellenőrizni kell, hogy a modul törlődött a listából. ', async () => {
        await expect(page.getByText(data.defaultModule, { exact: true })).toHaveCount(0);
    });




}
