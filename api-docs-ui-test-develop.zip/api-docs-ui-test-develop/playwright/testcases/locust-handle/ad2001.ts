import { LocustPage } from '@pages/locust.page';
import { test, Page } from '@playwright/test';
import { locustMenu } from '@resources/locust-handle/common-locust';

export async function ad2001(page: Page): Promise<void> {
    const locustNavigation = new LocustPage(page);

    await test.step('Rá kell kattintani a navigációs sáv **Eszközök** menüjében lévő **Locust generátor** gombra.', async () => {
        await locustMenu(locustNavigation);
    });

    await test.step('Rá kell kattintani a **Projekt generálás** gombra.', async () => {
        await locustNavigation.projectGeneration.click();
    });


}
