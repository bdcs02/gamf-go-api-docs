import { DetailsPage } from '@pages/details.page';
import { ListPage } from '@pages/list.page';
import { test, Page, expect } from '@playwright/test';
import { getDownloadedFileContent, selectOption } from '@resources/common';

export async function ad1207(page: Page, exportData: any): Promise<void> {
	const listPage = new ListPage(page);
	const detailsPage = new DetailsPage(page);
	let content = '';
	await test.step('Rá kell kattintani a **Keresés** beviteli mezőre.', async () => {
		await page.getByPlaceholder('Keresés').fill(exportData.search);
	});

	await test.step('Rá kell kattintani a **Method** lenyíló listára', async () => {
		await page.getByText('Method').click();
	});

	await test.step(' Ki kell választani a **Method** lenyíló listában a methodot a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
		await selectOption(exportData.method, page);
	});

	await test.step('Rá kell kattintani a **Keresés** gombra.', async () => {
		await listPage.searchButton.click();
	});

	await test.step('Rá kell kattintani a **TESZTELÉS PARAMÉTEREI** alapján megadott végpontra.', async () => {
		await page.getByRole('button', { name: '/' + exportData.search + ' ' + exportData.method }).click();
	});

	await test.step('Rá kell kattintani a **Részletek** gombra.', async () => {
		await listPage.detailsButton.click();
	});

	await test.step('Rá kell kattinta a **Header lista** menüpontra.', async () => {
		await detailsPage.headerListMenu.click();
	});

	await test.step('Ki kell tölteni a **Header név** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
		await detailsPage.keyInput.fill(exportData.headerKey);
	});

	await test.step('Ki kell tölteni a **Header érték** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
		await detailsPage.valueInput.fill(exportData.headerValue);
	});

	await test.step('Rá kell kattintani az almenü pontban a **Kérés exportálás** menüpontra.', async () => {
		await page.locator('button').filter({ hasText: 'more_vert' }).click();
	});

	await test.step('Rá kell kattintani az almenü pontban a **Kérés exportálás** menüpontra.', async () => {
		content = await getDownloadedFileContent(detailsPage.exportRequestButton, page);
	});

	await test.step('Ellenőrizni kell, hogy a fájl sikeresen letöltődött és tartalmazza a **TESZTELÉS PARAMÉTEREI** táblázatban szereplő headert.', async () => {
		await expect(content.includes(exportData.headerKey)).toBeTruthy();
		await expect(content.includes(exportData.headerValue)).toBeTruthy();
	});
}
