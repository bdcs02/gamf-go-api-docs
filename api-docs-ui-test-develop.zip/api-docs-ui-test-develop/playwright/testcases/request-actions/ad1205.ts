import { DetailsPage } from '@pages/details.page';
import { ListPage } from '@pages/list.page';
import { test, Page, expect } from '@playwright/test';
import { expectNoRows, selectOption } from '@resources/common';

export async function ad1205(page: Page, deleteData: any): Promise<void> {
	const listPage = new ListPage(page);
	const detailsPage = new DetailsPage(page);

	await test.step('Rá kell kattintani a **Keresés** beviteli mezőre.', async () => {
		await page.getByPlaceholder('Keresés').fill(deleteData.search);
	});

	await test.step('Rá kell kattintani a **Method** lenyíló listára', async () => {
		await page.getByText('Method').click();
	});

	await test.step(' Ki kell választani a **Method** lenyíló listában a methodot a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
		await selectOption(deleteData.method, page);
	});

	await test.step('Rá kell kattintani a **Keresés** gombra.', async () => {
		await listPage.searchButton.click();
	});

	await test.step('Rá kell kattintani a **TESZTELÉS PARAMÉTEREI** alapján megadott végpontra.', async () => {
		await page.getByRole('button', { name: '/' + deleteData.search + ' ' + deleteData.method }).click();
	});

	await test.step('Rá kell kattintani a **Részletek** gombra.', async () => {
		await listPage.detailsButton.click();
	});

	await test.step('Rá kell kattintani az almenü pontban a **Kérés mentés** menüpontra.', async () => {
		await page.locator('button').filter({ hasText: 'more_vert' }).click();
	});

	await test.step('Rá kell kattintani az almenü pontban a **Kérés mentés** menüpontra.', async () => {
		await detailsPage.saveRequestButton.click();
	});

	await test.step('Ki kell tölteni a **Név** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
		await detailsPage.urlInput.fill(deleteData.requestName);
	});

	await test.step('Rá kell kattintani a **Mentés** gombra.', async () => {
		await detailsPage.requestAdd.click();
	});

	await test.step('Rá kell kattintani az almenü pontban a **Kérés betöltése** menüpontra.', async () => {
		await page.locator('button').filter({ hasText: 'more_vert' }).click();
	});

	await test.step('Rá kell kattintani az almenü pontban a **Kérés betöltése** menüpontra.', async () => {
		await detailsPage.loadRequestButton.click();
	});

	await test.step('Ki kell tölteni a **Szűrés** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
		await page.getByLabel('Szűrés').fill(deleteData.requestName);
	});

	await test.step('A **TESZTELÉS PARAMÉTEREI** mező sorában rá kell kattintani a **Műveletek** gombra.', async () => {
		await page.locator('#row-actions').click();
	});

	await test.step('A lenyíló listában rá kell kattintani a **Törlés** gombra.', async () => {
		await page.getByRole('menuitem', { name: 'Törlés' }).click();
	});

	await test.step('A lenyíló listában rá kell kattintani a **Törlés** gombra.', async () => {
		await page.getByRole('button', { name: 'Igen' }).click();
	});

	await test.step('Ki kell tölteni a **Szűrés** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
		await page.getByLabel('Szűrés').fill(deleteData.requestName);
	});

	await test.step('A **TESZTELÉS PARAMÉTEREI** mező sorában rá kell kattintani a **Műveletek** gombra.', async () => {
		await expect(page.getByRole('button', { name: '/' + deleteData.search + ' ' + deleteData.method })).not.toBeVisible();
	});
}
