import { DetailsPage } from '@pages/details.page';
import { ListPage } from '@pages/list.page';
import { test, Page, expect } from '@playwright/test';
import { selectOption } from '@resources/common';

export async function ad1203(page: Page, loadData: any): Promise<void> {
	const listPage = new ListPage(page);
	const detailsPage = new DetailsPage(page);

	await test.step('Rá kell kattintani a **Keresés** beviteli mezőre.', async () => {
		await page.getByPlaceholder('Keresés').fill(loadData.search);
	});

	await test.step('Rá kell kattintani a **Method** lenyíló listára', async () => {
		await page.getByText('Method').click();
	});

	await test.step(' Ki kell választani a **Method** lenyíló listában a methodot a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
		await selectOption(loadData.method, page);
	});

	await test.step('Rá kell kattintani a **Keresés** gombra.', async () => {
		await listPage.searchButton.click();
	});

	await test.step('Rá kell kattintani a **TESZTELÉS PARAMÉTEREI** alapján megadott végpontra.', async () => {
		await page.getByRole('button', { name: '/' + loadData.search + ' ' + loadData.method }).click();
	});

	await test.step('Rá kell kattintani a **Részletek** gombra.', async () => {
		await listPage.detailsButton.click();
	});

	await test.step('Rá kell kattinta a **Header lista** menüpontra.', async () => {
		await detailsPage.headerListMenu.click();
	});

	await test.step('Ki kell tölteni a **Header név** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
		await detailsPage.keyInput.fill(loadData.headerKey);
	});

	await test.step('Ki kell tölteni a **Header érték** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
		await detailsPage.valueInput.fill(loadData.headerValue);
	});

	await test.step('Rá kell kattintani az almenü pontban a **Kérés mentés** menüpontra.', async () => {
		await page.locator('button').filter({ hasText: 'more_vert' }).click();
	});

	await test.step('Rá kell kattintani az almenü pontban a **Kérés mentés** menüpontra.', async () => {
		await detailsPage.saveRequestButton.click();
	});

	await test.step('Ki kell tölteni a **Név** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
		await detailsPage.urlInput.fill(loadData.requestName);
	});

	await test.step('Rá kell kattintani a **Mentés** gombra.', async () => {
		await detailsPage.requestAdd.click();
	});

	await test.step('Rá kell kattintani a **API DOC UI** gombra.', async () => {
		await page.getByText('API DOC UI').click();
	});

	await test.step('Rá kell kattintani a **Keresés** beviteli mezőre.', async () => {
		await page.getByPlaceholder('Keresés').fill(loadData.search);
	});

	await test.step('Rá kell kattintani a **Method** lenyíló listára', async () => {
		await page.getByText('Method').click();
	});

	await test.step(' Ki kell választani a **Method** lenyíló listában a methodot a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
		await selectOption(loadData.method, page);
	});

	await test.step('Rá kell kattintani a **Keresés** gombra.', async () => {
		await listPage.searchButton.click();
	});

	await test.step('Rá kell kattintani a **TESZTELÉS PARAMÉTEREI** alapján megadott végpontra.', async () => {
		await page.getByRole('button', { name: '/' + loadData.search + ' ' + loadData.method }).click();
	});

	await test.step('Rá kell kattintani a **Részletek** gombra.', async () => {
		await listPage.detailsButton.click();
	});

	await test.step('Rá kell kattintani az almenü pontban a **Kérés mentés** menüpontra.', async () => {
		await page.locator('button').filter({ hasText: 'more_vert' }).click();
	});

	await test.step('Rá kell kattintani az almenü pontban a **Kérés betöltése** menüpontra.', async () => {
		await detailsPage.loadRequestButton.click();
	});

	await test.step('Ki kell tölteni a **Szűrés** mezőt a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
		await page.getByLabel('Szűrés').fill(loadData.requestName);
	});

	await test.step('A **TESZTELÉS PARAMÉTEREI** mező sorában rá kell kattintani a **Műveletek** gombra.', async () => {
		await page.locator('#row-actions').click();
	});

	await test.step('A lenyíló listában rá kell kattintani a **Betöltés** gombra.', async () => {
		await page.getByRole('menuitem', { name: 'Betöltés' }).click();
		await page.mouse.click(0, 0);
	});

	await test.step('Rá kell kattinta a **Header lista** oldalsó menüpontra.', async () => {
		await detailsPage.headerListMenu.click();
	});

	await test.step('Ellenőrizni kell, hogy a **Header név** és a **Header érték** tartalmazza a **TESZTELÉS PARAMÉTEREI** táblázat adatát.', async () => {
		await expect(detailsPage.keyInput).toHaveValue(loadData.headerKey);
		await expect(detailsPage.valueInput).toHaveValue(loadData.headerValue);
	});
}
