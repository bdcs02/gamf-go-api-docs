import { NavigationPage } from '@pages/navigation.page';
import { test, Page, expect } from '@playwright/test';
import { getDownloadedFileContent, searchAndFilterEndpoint, selectOption } from '@resources/common';
import { checkBodyAndHeader } from '@resources/request-handle/common-request';

export async function ad1131(page: Page, data: any): Promise<void> {
    const navigationPage = new NavigationPage(page);

    await searchAndFilterEndpoint(data, page, navigationPage);

    await test.step('Rá kell kattintani a **Részletek** gombra.', async () => {
        await navigationPage.detailsButton.click();
    });

    await test.step('Rá kell kattintani a **Kérés küldése** gombra.', async () => {
        await navigationPage.sendRequestButton.click();
    });

    await test.step('Rá kell kattintani a **Response body letöltése** gombra.', async () => {
        await getDownloadedFileContent(navigationPage.responseDownloadButton, page);
    });
}
