import { NavigationPage } from '@pages/navigation.page';
import { test, Page, expect } from '@playwright/test';
import { searchAndFilterEndpoint, selectOption } from '@resources/common';
import { checkBodyAndHeader } from '@resources/request-handle/common-request';

export async function ad1117(page: Page, data: any): Promise<void> {
    const navigationPage = new NavigationPage(page);

    await searchAndFilterEndpoint(data, page, navigationPage);

    await test.step('Rá kell kattintani a **Részletek** gombra.', async () => {
        await navigationPage.detailsButton.click();
    });

    await test.step('Rá kell kattintani a **Header lista** navigációs gombra.', async () => {
        await navigationPage.headerButton.click();
    });

    await test.step('Ki kell tölteni a **Header név** mezőt a **TESZTELÉS PARAMÉTEREI** alapján.', async () => {
        await page.getByLabel('Header név').fill(data.header[0].key)
    });

    await test.step('Ki kell tölteni az **Header érték** mezőt a **TESZTELÉS PARAMÉTEREI** alapján.', async () => {
        await page.getByLabel('Header érték').fill(data.header[0].value)
    });

    await test.step('Rá kell kattintani a **Törlés** gombra.', async () => {
        await page.locator('#delete').click();
    });

    await test.step('Ellenőrizni kell, hogy a **Header név** és **Header érték** nem jelenik meg.', async () => {
        await expect(page.getByLabel('Header név')).toHaveCount(0);
        await expect(page.getByLabel('Header érték')).toHaveCount(0);
    });
}
