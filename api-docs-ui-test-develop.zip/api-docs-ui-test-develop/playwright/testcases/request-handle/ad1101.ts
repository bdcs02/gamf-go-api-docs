import { NavigationPage } from '@pages/navigation.page';
import { test, Page, expect } from '@playwright/test';
import { searchAndFilterEndpoint, selectOption } from '@resources/common';
import { checkBodyAndHeader } from '@resources/request-handle/common-request';

export async function ad1101(page: Page, data: any): Promise<void> {
    const navigationPage = new NavigationPage(page);

    await searchAndFilterEndpoint(data, page, navigationPage);

    await test.step('Rá kell kattintani a **Részletek** gombra.', async () => {
        await navigationPage.detailsButton.click();
    });

    await test.step('Rá kell kattintani a **Request body** navigációs gombra.', async () => {
        await navigationPage.requestBodyButton.click();
    });

    await test.step(' Rá kell kattintani a lenyíló listára.', async () => {
        await page.locator('#type-input').click();
    });

    await test.step(' Rá kell kattintani a lenyíló listában a **JSON** elemre.', async () => {
        await selectOption('JSON', page);
    });

    await test.step('Rá kell kattintani a **Kérés küldése** gombra.', async () => {
        await navigationPage.sendRequestButton.click();
    });

    await test.step('Ellenőrizni kell, hogy a **Response body** és **Response header** megjelenik.', async () => {
        await checkBodyAndHeader(page);
    });
}
