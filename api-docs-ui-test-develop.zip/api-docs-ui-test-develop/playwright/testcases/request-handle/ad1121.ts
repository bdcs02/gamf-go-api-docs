import { NavigationPage } from '@pages/navigation.page';
import { test, Page, expect } from '@playwright/test';
import { searchAndFilterEndpoint, selectOption } from '@resources/common';
import { checkBodyAndHeader } from '@resources/request-handle/common-request';

export async function ad1121(page: Page, data: any): Promise<void> {
    const navigationPage = new NavigationPage(page);

    await searchAndFilterEndpoint(data, page, navigationPage);

    await test.step('Rá kell kattintani a **Részletek** gombra.', async () => {
        await navigationPage.detailsButton.click();
    });

    await test.step('Rá kell kattintani a **URL paraméterek** navigációs gombra.', async () => {
        await navigationPage.urlParamsButton.click();
    });

    await test.step('Ki kell tölteni a **Paraméter név** mezőt a **TESZTELÉS PARAMÉTEREI** alapján.', async () => {
        await page.getByLabel('Paraméter név').fill(data.urlParam[0].key)
    });

    await test.step('Ki kell tölteni az **Paraméter érték** mezőt a **TESZTELÉS PARAMÉTEREI** alapján.', async () => {
        await page.getByLabel('Paraméter érték').fill(data.urlParam[0].value)
    });

    await test.step('Rá kell kattintani a **Törlés** gombra.', async () => {
        await page.locator('#delete').click();
    });

    await test.step('Ellenőrizni kell, hogy a **Paraméter név** és **Paraméter érték** nem jelenik meg.', async () => {
        await expect(page.getByLabel('Paraméter név')).toHaveCount(0);
        await expect(page.getByLabel('Paraméter érték')).toHaveCount(0);
    });
}
