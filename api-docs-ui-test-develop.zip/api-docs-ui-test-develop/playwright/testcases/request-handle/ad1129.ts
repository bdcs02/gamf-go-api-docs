import { NavigationPage } from '@pages/navigation.page';
import { test, Page, expect } from '@playwright/test';
import { searchAndFilterEndpoint, selectOption } from '@resources/common';
import { checkBodyAndHeader } from '@resources/request-handle/common-request';

export async function ad1129(page: Page, data: any): Promise<void> {
    const navigationPage = new NavigationPage(page);


    await test.step('Rá kell kattintani a **Globális változók** gombra.', async () => {
        await navigationPage.globalVariableButton.click();
    });

    await test.step('Ki kell tölteni a **Változó név** mezőt a **TESZTELÉS PARAMÉTEREI** alapján.', async () => {
        await page.getByText('Változó név').fill(data.globalVariable[0].key)
    });

    await test.step('Ki kell tölteni az **Változó érték** mezőt a **TESZTELÉS PARAMÉTEREI** alapján.', async () => {
        await page.getByText('Változó érték').fill(data.globalVariable[0].value)
    });

    await test.step('Rá kell kattintani a **Mentés** gombra.', async () => {
        await page.getByText('Mentés').click();
    });

    await test.step('Rá kell kattintani a **Globális változók** gombra.', async () => {
        await navigationPage.globalVariableButton.click();
    });

    await test.step('Rá kell kattintani a **Törlés** gombra.', async () => {
        await page.locator('#delete').click();
    });

    await test.step('Ellenőrizni kell, hogy a **Változó név** és **Változó érték** nem jelenik meg.', async () => {
        await expect(page.getByLabel('Változó név')).toHaveCount(0);
        await expect(page.getByLabel('Változó érték')).toHaveCount(0);
    });
}
