import { ListPage } from '@pages/list.page';
import { test, Page } from '@playwright/test';
import { getDownloadedFileContent } from '@resources/common';

export async function ad1003(page: Page): Promise<void> {
	const listPage = new ListPage(page);

	await test.step('Rá kell kattintani az **Export** gombra.', async () => {
		await getDownloadedFileContent(listPage.exportButton, page);
	});
}
