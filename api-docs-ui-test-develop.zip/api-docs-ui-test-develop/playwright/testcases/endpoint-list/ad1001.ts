import { ListPage } from '@pages/list.page';
import { test, Page } from '@playwright/test';
import { selectOption } from '@resources/common';

export async function ad1001(page: Page, filterData: any): Promise<void> {
	const listPage = new ListPage(page);

	await test.step('Rá kell kattintani a **Keresés** beviteli mezőre.', async () => {
		await page.getByPlaceholder('Keresés').fill(filterData.search);
	});

	await test.step('Rá kell kattintani a **Method** lenyíló listára', async () => {
		await page.getByText('Method').click();
	});

	await test.step('Rá kell kattintani a lenyíló listában a **TESZTELÉS PARAMÉTEREI** táblázat alapján megadott elemre.', async () => {
		await selectOption(filterData.method, page);
	});

	await test.step('Rá kell kattintani a **Keresés** gombra.', async () => {
		await listPage.searchButton.click();
	});

	await test.step('Ellenőrizni kell, hogy megjelenik a listában a **TESZTELÉS PARAMÉTEREI** alapján keresett végpont.', async () => {
		await page.getByRole('button', { name: '/' + filterData.search + ' ' + filterData.method });
	});
}
