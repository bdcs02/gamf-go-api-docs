export const workflow204Data = {
    search: 'text',
    method: 'GET',
    urlParam: [
        {
            key: 'Teszt paraméter kulcs',
            value: 'Teszt paraméter érték'
        }
    ]
};
