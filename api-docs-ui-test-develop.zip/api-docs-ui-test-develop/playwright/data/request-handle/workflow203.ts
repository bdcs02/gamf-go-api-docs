export const workflow203Data = {
    search: 'text',
    method: 'GET',
    header: [
        {
            key: 'Teszt Header kulcs',
            value: 'Teszt Header érték'
        }
    ]
};
