export const workflow206Data = {
    search: 'text',
    method: 'GET',
    globalVariable: [
        {
            key: 'Teszt globális változó kulcs',
            value: 'Teszt globális változó érték'
        }
    ]
};
