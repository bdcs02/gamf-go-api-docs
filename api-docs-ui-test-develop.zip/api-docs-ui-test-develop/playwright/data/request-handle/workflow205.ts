export const workflow205Data = {
    search: 'text',
    method: 'GET',
    variable: [
        {
            key: 'Teszt változó kulcs',
            value: 'Teszt változó érték'
        }
    ]
};
