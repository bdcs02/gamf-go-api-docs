export const workflow201Data = {
    search: 'text',
    method: 'GET',
    formData: [
        { key: 'Teszt kulcs form data', value: 'Teszt érték form data' },
    ]
};
