export const workflow202Data = {
    search: 'text',
    method: 'GET',
    bearer: '123456',
    apiKey: [
        {
            key: 'Teszt Api Key kulcs',
            value: 'Teszt Api Key érték'
        }
    ],
    header: [
        {
            key: 'Teszt Header kulcs',
            value: 'Teszt Header érték'
        }
    ]
};
