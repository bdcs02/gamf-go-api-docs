export const workflow101FilterData = {
	search: 'session',
	method: 'GET'
};
