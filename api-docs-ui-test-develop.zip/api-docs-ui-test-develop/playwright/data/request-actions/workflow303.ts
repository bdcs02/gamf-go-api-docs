export const workflow303SaveData = {
	search: 'text',
	method: 'GET',
	requestName: 'Teszt kérés név betöltéshez'
};

export const workflow303ExportData = {
	search: 'text',
	method: 'POST',
	requestName: 'Teszt kérés név betöltéshez',

	headerKey: 'Teszt header név kérés exportáláshoz',
	headerValue: 'Teszt header érték kérés exportáláshoz'
};
