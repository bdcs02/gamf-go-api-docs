export const workflow302SaveData = {
	search: 'text',
	method: 'GET',
	requestName: 'Teszt kérés név betöltéshez'
};

export const workflow302LoadData = {
	search: 'text',
	method: 'POST',
	requestName: 'Teszt kérés név betöltéshez',

	headerKey: 'Teszt header név kérés betöltése',
	headerValue: 'Teszt header érték kérés betöltéshez'
};
