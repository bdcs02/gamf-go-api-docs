export const workflow301SaveData = {
	search: 'text',
	method: 'GET',
	requestName: 'Teszt kérés név mentéshez'
};

export const workflow301DeleteData = {
	search: 'text',
	method: 'POST',
	requestName: 'Teszt kérés név törléshez'
};
