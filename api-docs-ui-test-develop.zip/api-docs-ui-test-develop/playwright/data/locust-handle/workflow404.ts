export const workflow404Data = {
    add: {
        name: 'Teszt authorizáció név hozzáadáshoz',
        type: 'Bearer Token'
    },
    defaultAuth: 'defaultAuth (OAuth)',
};
