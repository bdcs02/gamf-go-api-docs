export const workflow406Data = {
    dictionary: "Teszt szótár felvétel",
    word: "Teszt szó"
};
