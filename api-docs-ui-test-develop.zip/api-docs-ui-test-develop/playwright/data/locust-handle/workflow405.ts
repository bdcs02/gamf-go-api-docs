export const workflow405Data = {
    key: "Teszt kulcs fájl felvételhez"
};
