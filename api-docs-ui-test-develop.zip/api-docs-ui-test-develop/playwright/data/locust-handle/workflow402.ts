export const workflow402Data = {
    host: "https://api-docs-dev.k8s-dev.ibc",
    userNumber: "2",
    spawnRate: "5",
    logLevel: "WARNING",
    runTime: "2",
    seed: "10",
    locale: "en",
};
