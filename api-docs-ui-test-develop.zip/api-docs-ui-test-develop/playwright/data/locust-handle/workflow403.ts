export const workflow403Data = {
    name: "Teszt modul név",
    defaultModule: 'modul',
    endpointLong: 'GET /logout',
    endpointShort: '/logout'
};
