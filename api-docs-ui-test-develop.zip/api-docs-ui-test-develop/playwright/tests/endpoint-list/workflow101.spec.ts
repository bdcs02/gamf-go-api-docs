import { test } from '@fixtures/basefixture';
import { ad1001 } from '@testcases/endpoint-list/ad1001';
import { ad1003 } from '@testcases/endpoint-list/ad1003';
import { workflow101FilterData } from 'data/endpoint-list/workflow101';

test.describe.only('WORKFLOW-101 - Végpontok lista kezelése', () => {
    test.describe.configure({ mode: 'serial' });

    test('AD-1001 - Végpont szűrés', async ({ page }) => {
        await ad1001(page, workflow101FilterData);
    });

    test('AD-1003 - Végpont exportálása', async ({ page }) => {
        await ad1003(page);
    });
});
