import { test } from '@fixtures/basefixture';
import { ad2117 } from '@testcases/locust-handle/ad2117';
import { ad2119 } from '@testcases/locust-handle/ad2119';
import { workflow406Data } from 'data/locust-handle/workflow406';

test.describe.only('WORKFLOW-406 - Szótár kezelése', () => {
    test.describe.configure({ mode: 'serial' });

    test('AD-2117 - Szótár hozzáadása', async ({ page }) => {
        await ad2117(page, workflow406Data);
    });

    test('AD-2119 - Szótár törlése', async ({ page }) => {
        await ad2119(page, workflow406Data);
    });
});
