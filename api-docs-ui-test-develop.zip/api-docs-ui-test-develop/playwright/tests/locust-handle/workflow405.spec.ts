import { test } from '@fixtures/basefixture';
import { ad2113 } from '@testcases/locust-handle/ad2113';
import { ad2115 } from '@testcases/locust-handle/ad2115';
import { workflow405Data } from 'data/locust-handle/workflow405';

test.describe.only('WORKFLOW-405 - Fájlok kezelése', () => {
    test.describe.configure({ mode: 'serial' });

    test('AD-2113 - Locust fájl felvétele', async ({ page }) => {
        await ad2113(page, workflow405Data);
    });

    test('AD-2115 - Locust fájl törlése', async ({ page }) => {
        await ad2115(page, workflow405Data);
    });
});
