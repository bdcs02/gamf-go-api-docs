import { test } from '@fixtures/basefixture';
import { ad2001 } from '@testcases/locust-handle/ad2001';
import { ad2003 } from '@testcases/locust-handle/ad2003';

test.describe.only('WORKFLOW-401 - Locust funkciók kezelése', () => {
    test.describe.configure({ mode: 'serial' });

    test('AD-2001 - Projekt generálása', async ({ page }) => {
        await ad2001(page);
    });
    test('AD-2003 - Projekt exportálása', async ({ page }) => {
        await ad2003(page);
    });
});
