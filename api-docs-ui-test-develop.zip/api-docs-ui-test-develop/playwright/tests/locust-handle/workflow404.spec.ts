import { test } from '@fixtures/basefixture';
import { ad2109 } from '@testcases/locust-handle/ad2109';
import { ad2111 } from '@testcases/locust-handle/ad2111';
import { workflow404Data } from 'data/locust-handle/workflow404';

test.describe.only('WORKFLOW-404 - Authorizáció kezelése', () => {
    test.describe.configure({ mode: 'serial' });

    test('AD-2109 - Authorizáció hozzáadása', async ({ page }) => {
        await ad2109(page, workflow404Data);
    });

    test('AD-2111 - Authorizáció törlése', async ({ page }) => {
        await ad2111(page, workflow404Data);
    });
});
