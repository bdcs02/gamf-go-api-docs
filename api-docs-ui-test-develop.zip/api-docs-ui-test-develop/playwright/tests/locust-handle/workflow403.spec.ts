import { test } from '@fixtures/basefixture';
import { ad2101 } from '@testcases/locust-handle/ad2101';
import { ad2103 } from '@testcases/locust-handle/ad2103';
import { ad2105 } from '@testcases/locust-handle/ad2105';
import { ad2107 } from '@testcases/locust-handle/ad2107';
import { ad2123 } from '@testcases/locust-handle/ad2123';

import { workflow403Data } from 'data/locust-handle/workflow403';

test.describe.only('WORKFLOW-403 - Modul kezelése', () => {
    test.describe.configure({ mode: 'serial' });

    test('AD-2101 - Modul hozzáadása', async ({ page }) => {
        await ad2101(page, workflow403Data);
    });
    test('AD-2103 - Modul törlése', async ({ page }) => {
        await ad2103(page, workflow403Data);
    });
    test('AD-2105 - Végpont hozzáadása', async ({ page }) => {
        await ad2105(page, workflow403Data);
    });
    test('AD-2107 - Végpont törlése', async ({ page }) => {
        await ad2107(page, workflow403Data);
    });
    test('AD-2123 - Generált kód megtekintése', async ({ page }) => {
        await ad2123(page);
    });
});
