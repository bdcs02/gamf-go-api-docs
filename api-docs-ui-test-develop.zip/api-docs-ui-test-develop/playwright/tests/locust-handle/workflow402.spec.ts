import { test } from '@fixtures/basefixture';
import { ad2109 } from '@testcases/locust-handle/ad2109';
import { ad2111 } from '@testcases/locust-handle/ad2111';
import { ad2121 } from '@testcases/locust-handle/ad2121';
import { ad1123 } from '@testcases/request-handle/ad1123';
import { ad1125 } from '@testcases/request-handle/ad1125';
import { workflow402Data } from 'data/locust-handle/workflow402';
import { workflow404Data } from 'data/locust-handle/workflow404';

test.describe.only('WORKFLOW-402 - Általános kezelése', () => {
    test.describe.configure({ mode: 'serial' });

    test('AD-2121 - Általános adatok mentése', async ({ page }) => {
        await ad2121(page, workflow402Data);
    });
});
