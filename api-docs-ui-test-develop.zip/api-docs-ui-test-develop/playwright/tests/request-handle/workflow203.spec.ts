import { test } from '@fixtures/basefixture';
import { ad1115 } from '@testcases/request-handle/ad1115';
import { ad1117 } from '@testcases/request-handle/ad1117';
import { workflow203Data } from 'data/request-handle/workflow203';

test.describe.only('WORKFLOW-203 - Header lista kezelése', () => {
    test.describe.configure({ mode: 'serial' });

    test('AD-1115 - Header hozzáadása', async ({ page }) => {
        await ad1115(page, workflow203Data);
    });

    test('AD - 1117 - Header törlése', async ({ page }) => {
        await ad1117(page, workflow203Data);
    });
});
