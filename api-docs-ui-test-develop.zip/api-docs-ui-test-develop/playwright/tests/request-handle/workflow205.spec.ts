import { test } from '@fixtures/basefixture';
import { ad1123 } from '@testcases/request-handle/ad1123';
import { ad1125 } from '@testcases/request-handle/ad1125';
import { workflow205Data } from 'data/request-handle/workflow205';

test.describe.only('WORKFLOW-205 - Változók kezelése', () => {
    test.describe.configure({ mode: 'serial' });

    test('AD-1123 - Változók hozzáadása', async ({ page }) => {
        await ad1123(page, workflow205Data);
    });

    test('AD-1125 - Változók törlése', async ({ page }) => {
        await ad1125(page, workflow205Data);
    });
});
