import { test } from '@fixtures/basefixture';
import { ad1101 } from '@testcases/request-handle/ad1101';
import { ad1103 } from '@testcases/request-handle/ad1103';
import { ad1105 } from '@testcases/request-handle/ad1105';
import { ad1131 } from '@testcases/request-handle/ad1131';
import { workflow201Data } from 'data/request-handle/workflow201';

test.describe.only('WORKFLOW-201 - Request body kezelése', () => {
    test.describe.configure({ mode: 'serial' });

    test('AD-1101 - JSON Request body hozzáadása', async ({ page }) => {
        await ad1101(page, workflow201Data);
    });

    test('AD-1103 - Szöveg Request body hozzáadása', async ({ page }) => {
        await ad1103(page, workflow201Data);
    });

    test('AD-1105 - Form Data Request body hozzáadása', async ({ page }) => {
        await ad1105(page, workflow201Data);
    });

    test('AD-1131 - Response body letöltése', async ({ page }) => {
        await ad1131(page, workflow201Data);
    });
});
