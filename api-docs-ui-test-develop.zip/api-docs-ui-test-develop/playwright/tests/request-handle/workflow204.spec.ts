import { test } from '@fixtures/basefixture';
import { ad1119 } from '@testcases/request-handle/ad1119';
import { ad1121 } from '@testcases/request-handle/ad1121';
import { workflow204Data } from 'data/request-handle/workflow204';

test.describe.only('WORKFLOW-204 - URL paraméterek kezelése', () => {
    test.describe.configure({ mode: 'serial' });

    test('AD-1119 - URL paraméterek hozzáadása', async ({ page }) => {
        await ad1119(page, workflow204Data);
    });

    test('AD-1121 - URL paraméterek törlése', async ({ page }) => {
        await ad1121(page, workflow204Data);
    });
});
