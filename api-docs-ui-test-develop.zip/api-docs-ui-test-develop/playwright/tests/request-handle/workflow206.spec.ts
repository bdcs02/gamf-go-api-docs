import { test } from '@fixtures/basefixture';
import { ad1127 } from '@testcases/request-handle/ad1127';
import { ad1129 } from '@testcases/request-handle/ad1129';
import { workflow206Data } from 'data/request-handle/workflow206';

test.describe.only('WORKFLOW-206 - Globális változók kezelése', () => {
    test.describe.configure({ mode: 'serial' });

    test('AD-1127 - Globális változók hozzáadása', async ({ page }) => {
        await ad1127(page, workflow206Data);
    });

    test('AD-1129 - Globális változók törlése', async ({ page }) => {
        await ad1129(page, workflow206Data);
    });
});
