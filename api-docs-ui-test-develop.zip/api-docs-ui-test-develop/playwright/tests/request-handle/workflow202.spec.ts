import { test } from '@fixtures/basefixture';
import { ad1109 } from '@testcases/request-handle/ad1109';
import { ad1111 } from '@testcases/request-handle/ad1111';
import { ad1113 } from '@testcases/request-handle/ad1113';
import { workflow202Data } from 'data/request-handle/workflow202';

test.describe.only('WORKFLOW-202 - Authorizáció kezelése', () => {
    test.describe.configure({ mode: 'serial' });

    test('AD-1109 - Bearer Token hozzáadása', async ({ page }) => {
        await ad1109(page, workflow202Data);
    });

    test('AD-1111 - API Key hozzáadása', async ({ page }) => {
        await ad1111(page, workflow202Data);
    });

    test('AD-1113 - Keycloak hozzáadása', async ({ page }) => {
        await ad1113(page, workflow202Data);
    });
});
