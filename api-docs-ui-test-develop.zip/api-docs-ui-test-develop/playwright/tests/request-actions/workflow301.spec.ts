import { test } from '@fixtures/basefixture';
import { ad1201 } from '@testcases/request-actions/ad1201';
import { ad1205 } from '@testcases/request-actions/ad1205';
import { workflow301DeleteData, workflow301SaveData } from 'data/request-actions/workflow301';

test.describe.only('WORKFLOW-301 - Kérés törlése', () => {
	test.describe.configure({ mode: 'serial' });

	test('AD-1201 - Kérés mentés', async ({ page }) => {
		await ad1201(page, workflow301SaveData);
	});

	test('AD-1205 - Kérés törlés', async ({ page }) => {
		await ad1205(page, workflow301DeleteData);
	});
});
