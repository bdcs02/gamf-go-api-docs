import { test } from '@fixtures/basefixture';
import { ad1201 } from '@testcases/request-actions/ad1201';
import { ad1207 } from '@testcases/request-actions/ad1207';
import { workflow303ExportData, workflow303SaveData } from 'data/request-actions/workflow303';

test.describe.only('WORKFLOW-303 - Kérések műveletei', () => {
	test.describe.configure({ mode: 'serial' });

	test('AD-1201 - Kérés mentés', async ({ page }) => {
		await ad1201(page, workflow303SaveData);
	});

	test('AD-1207 - Kérés exportálása', async ({ page }) => {
		await ad1207(page, workflow303ExportData);
	});
});
