import { test } from '@fixtures/basefixture';
import { ad1201 } from '@testcases/request-actions/ad1201';
import { ad1203 } from '@testcases/request-actions/ad1203';
import { workflow302LoadData, workflow302SaveData } from 'data/request-actions/workflow302';

test.describe.only('WORKFLOW-302 - Kérés betöltése', () => {
	test.describe.configure({ mode: 'serial' });

	test('AD-1201 - Kérés mentés', async ({ page }) => {
		await ad1201(page, workflow302SaveData);
	});

	test('AD-1203 - Kérés betöltés', async ({ page }) => {
		await ad1203(page, workflow302LoadData);
	});
});
