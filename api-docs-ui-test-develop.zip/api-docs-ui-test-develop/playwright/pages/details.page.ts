import { Locator, Page } from '@fixtures/basefixture';

export class DetailsPage {
	readonly page: Page;
	readonly saveRequestButton: Locator;
	readonly loadRequestButton: Locator;
	readonly exportRequestButton: Locator;
	readonly curlRequestButton: Locator;

	readonly urlInput: Locator;
	readonly requestAdd: Locator;
	readonly headerListMenu: Locator;

	readonly keyInput: Locator;
	readonly valueInput: Locator;

	constructor(page: Page) {
		this.page = page;
		this.saveRequestButton = page.locator('#nav-save-request');
		this.loadRequestButton = page.locator('#nav-load-request');
		this.exportRequestButton = page.locator('#nav-export-request');
		this.curlRequestButton = page.locator('#nav-curl');

		this.headerListMenu = page.locator('#nav-header-list');
		this.urlInput = page.locator('#url-input');
		this.requestAdd = page.locator('#request-add');
		this.keyInput = page.locator('#key-0');
		this.valueInput = page.locator('#value-0');
	}
}
