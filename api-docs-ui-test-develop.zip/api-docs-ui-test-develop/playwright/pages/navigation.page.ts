import { Locator, Page } from '@fixtures/basefixture';
import path from 'path';

export class NavigationPage {
	readonly page: Page;
	readonly searchInputField: Locator;
	readonly methodDropdown: Locator;
	readonly searchButton: Locator;
	readonly exportButton: Locator;
	readonly detailsButton: Locator;
	readonly requestBodyButton: Locator;
	readonly sendRequestButton: Locator;
	readonly methodButton: Locator;
	readonly endpointItem: Locator;
	readonly authorizeButton: Locator;
	readonly headerButton: Locator;
	readonly urlParamsButton: Locator;
	readonly variableButton: Locator;
	readonly keycloakButton: Locator;
	readonly globalVariableButton: Locator;
	readonly responseDownloadButton: Locator;

	constructor(page: Page) {
		this.page = page;
		this.searchInputField = page.locator('#search-input');
		this.methodDropdown = page.locator('#method-dropdown');
		this.searchButton = page.locator('#filter');
		this.exportButton = page.locator('#export');
		this.detailsButton = page.locator('#details');
		this.requestBodyButton = page.locator("#nav-request-body")
		this.sendRequestButton = page.locator('.send-request-button')
		this.methodButton = page.locator('#null-input');
		this.endpointItem = page.locator('.title-wrapper');
		this.authorizeButton = page.locator('#nav-authorization');
		this.headerButton = page.locator('#nav-header-list');
		this.urlParamsButton = page.locator('#nav-url-parameters');
		this.variableButton = page.locator('#nav-variables');
		this.keycloakButton = page.locator('.keycloak-authorization-button');
		this.globalVariableButton = page.locator('#global-variables');
		this.responseDownloadButton = page.locator('#downloadResponse');
	}
}
