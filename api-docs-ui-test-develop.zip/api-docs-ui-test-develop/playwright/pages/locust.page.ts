import { Locator, Page } from '@fixtures/basefixture';

export class LocustPage {
    readonly page: Page;
    readonly moduleTab: Locator;
    readonly toolsButton: Locator;
    readonly locustGenButton: Locator;
    readonly exportLocustButton: Locator;
    readonly projectGeneration: Locator;
    readonly addModul: Locator;
    readonly nameInput: Locator;
    readonly save: Locator;
    readonly delete: Locator;
    readonly dialogConfirm: Locator;
    readonly addEndpoint: Locator;
    readonly addOnClass: Locator;
    readonly authTypesDropdown: Locator;
    readonly fileUpload: Locator;
    readonly deleteDictionary: Locator;
    readonly addWord: Locator;
    readonly generalTab: Locator;
    readonly dictionaryTab: Locator;
    readonly confirmOption: Locator;
    readonly filesTab: Locator;
    readonly viewCode: Locator;
    readonly authTab: Locator;

    constructor(page: Page) {
        this.page = page;
        this.viewCode = page.locator('#eye');
        this.moduleTab = page.getByRole('tab', { name: 'Modulok' });
        this.generalTab = page.getByRole('tab', { name: 'Általános' });
        this.filesTab = page.getByRole('tab', { name: 'Fájlok' });
        this.authTab = page.getByRole('tab', { name: 'Authorizáció' });
        this.dictionaryTab = page.getByRole('tab', { name: 'Szótárak' });
        this.deleteDictionary = page.locator('#delete-dictionary');
        this.toolsButton = page.locator('#nav-tools');
        this.locustGenButton = page.locator('#nav-locust-generator');
        this.exportLocustButton = page.locator('#locust-export');
        this.projectGeneration = page.locator('#project-generation');
        this.addModul = page.locator('#add-modul')
        this.nameInput = page.locator('#name-input');
        this.save = page.locator('#save');
        this.confirmOption = page.getByRole('button', { name: 'Igen' });
        this.delete = page.locator('#delete');
        this.addEndpoint = page.locator('#add-endpoint');
        this.fileUpload = page.locator('#file-upload-0');
        this.addOnClass = page.locator('.add');
        this.addWord = page.locator('#addRow');
        this.authTypesDropdown = page.locator('#authTypes');
        this.dialogConfirm = page.locator('#LocustModulResponseComponent-dialog-confirm');
    }
}
