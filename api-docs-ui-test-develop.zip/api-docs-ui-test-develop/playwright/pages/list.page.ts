import { Locator, Page } from '@fixtures/basefixture';

export class ListPage {
	readonly page: Page;
	readonly searchInputField: Locator;
	readonly methodDropdown: Locator;
	readonly searchButton: Locator;
	readonly exportButton: Locator;
	readonly detailsButton: Locator;

	constructor(page: Page) {
		this.page = page;
		this.searchInputField = page.locator('#search-input');
		this.methodDropdown = page.locator('#method-dropdown');
		this.searchButton = page.locator('#filter');
		this.exportButton = page.locator('#export');
		this.detailsButton = page.locator('#details');
	}
}
