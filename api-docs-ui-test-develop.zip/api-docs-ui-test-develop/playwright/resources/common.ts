import { Locator, Page, expect, test } from '@fixtures/basefixture';

export async function loginUser(page: Page): Promise<void> {
	await test.step(`Be kell jelentkezni az alkalmazásba **TESZTELÉS PARAMÉTEREI táblázat** felhasználóval.`, async () => {
		await test.step('A **Username or email** mezőbe be kell írni a felhasználónevet a **TESZTELÉS PARAMÉTEREI táblázat** alapján.', async () => {
			await page.getByLabel('Username or email').fill(process.env.user_username);
		});

		await test.step('A **Password** mezőbe be kell írni a felhasználónévhez tartozó jelszót a **TESZTELÉS PARAMÉTEREI** táblázat alapján.', async () => {
			await page.getByLabel('Password', { exact: true }).fill(process.env.user_password);
		});

		await test.step('Rá kell kattintani a **Sign In** gombra.', async () => {
			await page.getByRole('button', { name: 'Sign In' }).click();
		});

		await test.step('Sikeres bejelentkezés ellenőrzése.', async () => {
			await expect(page.locator('mat-toolbar')).toBeVisible();
		});
	});
}

export async function expectTableColumnOnlyContains(columnCssClass: string, text: string, page: Page): Promise<void> {
	await expect(page.locator('mat-row').locator(columnCssClass).filter({ hasText: text }).first()).toHaveCount(1);
	await expect(page.locator('mat-row').locator(columnCssClass).filter({ hasNotText: text })).toHaveCount(0);
}

export async function expectTableContainSingleRowWithFilters(page: Page, ...filters: string[]) {
	await expect(addFiltersToLocator(page, page.locator('mat-row'), filters)).toHaveCount(1);
}

export function addFiltersToLocator(page: Page, locator: Locator, filters: string[]): Locator {
	for (const filter of filters) {
		locator = locator.filter({
			has: page.locator('mat-cell').getByText(filter, { exact: true })
		});
	}

	return locator;
}

export async function openMuveletek(cellValue: string, page: Page) {
	const cell = await page.getByRole('cell', { name: cellValue, exact: true });
	const row = await page.getByRole('row').filter({ has: cell });

	await row.locator('#row-actions').click();
}

export async function selectMuvelet(muvelet: string, page: Page): Promise<void> {
	await page.getByRole('menuitem', { name: muvelet }).click();
}

export async function selectFromDropdown(formControlName: string, value: string, page: Page) {
	await openDropdown(formControlName, page);
	await selectOption(value, page);
}

export async function openDropdown(formControlName: string, page: Page) {
	await page.locator(`dropdown-list[formcontrolname=${formControlName}]`).click();
}

export async function selectOption(option: string, page: Page): Promise<void> {
	const optionLocator = await page.getByRole('option', {
		name: option,
		exact: true
	});

	const listboxLocator = page.locator('div').filter({ has: optionLocator }).getByRole('listbox');

	await expect(optionLocator).toHaveCount(1);

	await optionLocator.click();

	await expect(listboxLocator).toHaveCount(0);
}

export async function clearDropdown(selector: string, page: Page): Promise<void> {
	await page.locator(selector).click();
	await page.getByRole('option').first().click();
}

export async function getDownloadedFileContent(exportButtonLocator: Locator, page: Page): Promise<string> {
	const fs = require('fs');

	const downloadPromise = page.waitForEvent('download');
	await exportButtonLocator.click();
	const download = await downloadPromise;
	const fileLocation = './downloads/' + download.suggestedFilename();
	await download.saveAs(fileLocation);

	const content = fs.readFileSync(fileLocation, {
		encoding: 'utf8'
	});

	fs.unlinkSync(fileLocation);

	return content;
}

export async function expectNoRows(page: Page): Promise<void> {
	await expect(page.locator('mat-row')).toHaveCount(0);
}

export async function expectCellWithValue(value: string, page: Page): Promise<void> {
	await expect(page.getByRole('cell', { name: value })).toHaveCount(1);
}

export async function clickFilterSearchInTable(tableTitle: string, page: Page): Promise<void> {
	await getCommonTableByTitle(tableTitle, page).locator('autocomplete-filter').locator('input').click({ force: true });
	await expect(page.locator('div').getByRole('listbox')).toHaveCount(1);
}

export async function clickSelectFilterInTable(tableTitle: string, page: Page): Promise<void> {
	await getCommonTableByTitle(tableTitle, page).getByLabel('Szűrő kiválasztása').click({ force: true });
}

export async function clickFilterInTable(tableTitle: string, page: Page): Promise<void> {
	await getCommonTableByTitle(tableTitle, page).locator('#filter-button').click();
}

export async function clickFilterSelectInTable(tableTitle: string, page: Page): Promise<void> {
	await getCommonTableByTitle(tableTitle, page).getByLabel('Válasszon szűrési feltételt!').click({ force: true });
}

export function getCommonTableByTitle(tableTitle: string, page: Page): Locator {
	return page.locator(`common-table:below(:text("${tableTitle}"))`).first();
}

export async function fillFilterValue(value: string, page: Page): Promise<void> {
	await page.getByLabel('Szűrőérték').fill(value);
}

export async function searchAndFilterEndpoint(data: any, page: Page, navigationPage: any): Promise<void> {
	await test.step('Rá kell kattintani a **Keresés** beviteli mezőre.', async () => {
		await page.getByPlaceholder('Keresés').fill(data.search);
	});
	await test.step('Rá kell kattintani a **Method** lenyíló listára', async () => {
		await navigationPage.methodButton.click();
	});

	await test.step('Rá kell kattintani a lenyíló listában a **TESZTELÉS PARAMÉTEREI** táblázat alapján megadott elemre.', async () => {
		await selectOption(data.method, page);
	});

	await test.step('Rá kell kattintani a **Keresés** gombra.', async () => {
		await navigationPage.searchButton.click();
	});

	await test.step('Rá kell kattintani a **TESZTELÉS PARAMÉTEREI** alapján megadott végpontra.', async () => {
		await navigationPage.endpointItem.click();
	});
}

