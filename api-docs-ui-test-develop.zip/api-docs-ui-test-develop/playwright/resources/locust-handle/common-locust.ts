import { LocustPage } from "@pages/locust.page";
import { Page, expect } from "@playwright/test";
import path from "path";

export async function uploadFile(locustPage: LocustPage, page: Page) {
    const fileChooserPromise = page.waitForEvent('filechooser');
    await locustPage.fileUpload.click();
    const fileChooser = await fileChooserPromise;
    await fileChooser.setFiles(path.join(__dirname, 'testFileUpload.txt'));
};

export async function clickConfirm(page: Page) {
    await expect(page.getByRole('button', { name: 'Igen' })).toBeVisible();
    await page.getByRole('button', { name: 'Igen' }).click();
};

export async function locustMenu(locustNavigation: LocustPage) {
    await locustNavigation.toolsButton.click();
    await locustNavigation.locustGenButton.click();
};



