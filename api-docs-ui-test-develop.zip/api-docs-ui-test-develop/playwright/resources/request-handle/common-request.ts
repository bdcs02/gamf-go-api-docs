import { Page } from "@playwright/test";
import { expect } from "@playwright/test";

export async function checkBodyAndHeader(page: Page) {
    await expect(page.getByText('Response body')).toBeVisible();
    await expect(page.getByText('Response header')).toBeVisible();
};

